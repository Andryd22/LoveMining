---
trigger: always_on
---

ogni volta che avviene una modifica all'interno del progetto 'LoveMining', mantieni aggiornato il file @spiegazione.md coerentemente a quanto presente nel progetto, così da avere sempre una visione aggiornata del tutto.