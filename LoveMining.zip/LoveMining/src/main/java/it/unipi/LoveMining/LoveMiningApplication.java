package it.unipi.LoveMining;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoveMiningApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoveMiningApplication.class, args);
	}

}
